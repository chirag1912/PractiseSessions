

var container=document.createElement('div');
container.setAttribute("class","container");


var row=document.createElement('div');
row.setAttribute("class","row");

var col1=document.createElement('div');
//col1.setAttribute("class","col-4 bg-primary");
col1.innerHTML="Row1 Col1";
col1.classList.add("col-4","bg-primary");

var col2=document.createElement('div');
col2.setAttribute("class","col-4 bg-warning");
col2.innerHTML="Row1 Col2";

var col3=document.createElement('div');
col3.setAttribute("class","col-4 bg-danger");
col3.innerHTML="Row1 Col3";




row.append(col1,col2,col3);
container.append(row);
document.body.append(container);